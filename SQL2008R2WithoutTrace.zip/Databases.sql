PRINT '-- Databases'
select * from sys.databases
