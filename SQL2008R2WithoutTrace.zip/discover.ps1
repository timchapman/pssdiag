#powershell -command set-executionpolicy Unrestricted

$xml=[xml](get-content "pssdiag.xml")
$VerNode=$xml.SelectSingleNode("//IntendedVersion");



$found=$false
$version=$VerNode.InnerText;
if ($version -eq  "10.50" )
{
    $version="10";
}


$ExactAssembly = "Microsoft.AnalysisServices,Version=" + $version + ".0.0.0,Culture=neutral,PublicKeyToken=89845dcd8080cc91";

try
{
    $asem= [Reflection.Assembly]::Load($ExactAssembly)
    $found=$true
    $asem | out-file "HASAMO.txt"
}
catch
{

    $found=$false	

}



