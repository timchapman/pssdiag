SET NOCOUNT ON
PRINT '-- MemoryClerks'
SELECT * FROM sys.dm_os_memory_clerks