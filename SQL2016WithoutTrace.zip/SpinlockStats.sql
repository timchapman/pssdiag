PRINT '-- Spinlocks'
select * from sys.dm_os_spinlock_stats