print '==== sp_configure'
select name, value_in_use from sys.configurations